package com.stephen.cuebue;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "cuebue_transactions")
public class Transaction {
    enum Type {
        Deposit,
        Transfer,
        AirtimeTopUp
    }

    enum Direction {
        Credit,
        Debit
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Enumerated(EnumType.STRING)
    private Direction direction;

    @Enumerated(EnumType.STRING)
    private Type type;

    private Double amount;

    private LocalDateTime date;

    private String message;

    @ManyToOne(fetch = FetchType.EAGER)
    private User user;

    @PostPersist
    private void postPersist() {
        date = LocalDateTime.now();
    }
}
