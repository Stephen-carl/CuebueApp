package com.stephen.cuebue;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class UserDAO {
    @PersistenceContext(name = "default")
    private EntityManager entityManager;

    public void save(final User user) {
        entityManager.persist(user);
    }

    public void update(final User user) {
        entityManager.merge(user);
    }

    public User findByPhoneNumber(final String phoneNumber) {
        return entityManager
                .createQuery("SELECT u FROM User u WHERE u.phoneNumber = ?1", User.class)
                .setParameter(1, phoneNumber)
                .getSingleResult();
    }

    public User findByAccountNumber(final String accountNumber) {
        return entityManager
                .createQuery("SELECT u FROM User u WHERE u.accountNumber = ?1", User.class)
                .setParameter(1, accountNumber)
                .getSingleResult();
    }
}
