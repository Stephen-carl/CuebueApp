package com.stephen.cuebue;

public class AirtimeService {
    public void topUp(final String network, final String phoneNumber, final double amount) {

    }
}
