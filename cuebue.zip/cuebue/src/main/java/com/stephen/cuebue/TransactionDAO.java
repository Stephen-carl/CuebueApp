package com.stephen.cuebue;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class TransactionDAO {
    @PersistenceContext(name = "default")
    private EntityManager entityManager;

    public void save(final Transaction transaction) {
        entityManager.persist(transaction);
    }
}
