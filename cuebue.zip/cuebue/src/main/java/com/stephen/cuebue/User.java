package com.stephen.cuebue;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "cuebue_users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;

    private String pin;

    @Column(unique = true)
    private String phoneNumber;

    @Column(unique = true)
    private String accountNumber;

    private Double accountBalance;

    private LocalDateTime date;

    @ToString.Exclude
    @OneToMany(mappedBy = "user")
    private List<Transaction> transactions;

    @PostPersist
    private void postPersist() {
        date = LocalDateTime.now();
    }
}
