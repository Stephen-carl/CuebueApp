package com.stephen.cuebue;

import org.apache.commons.lang3.RandomStringUtils;

import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.Objects;

@Transactional
@Path("/sms")
@Produces(MediaType.TEXT_PLAIN)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public class Resource {
    private static final String SIGN_UP = "SignUp";

    private static final String TOP_UP = "TopUp";

    private static final String TRANSFER = "Transfer";

    private static final String BALANCE = "Balance";

    @Inject
    private UserDAO userDAO;

    @Inject
    private TransactionDAO transactionDAO;

    @Inject
    private SMSService smsService;

    @Inject
    private AirtimeService airtimeService;

    private User user;

    @POST
    public String start(
        @FormParam("sender") final String sender,
        @FormParam("message") final String message
    ) {
        final String[] params = message.split(",");

        try {
            switch (params[0]) {
                case SIGN_UP:
                    signUp(params[1], sender, params[2]);
                    break;

                case TOP_UP:
                    validateUser(sender, params[4]);
                    topUp(params[1], params[2], params[3]);
                    break;

                case TRANSFER:
                    validateUser(sender, params[3]);
                    transfer(params[1], params[2]);
                    break;

                case BALANCE:
                    validateUser(sender, params[1]);
                    balance();
                    break;

                default:
            }
        } catch (IllegalArgumentException ignored) {}

        return params[0];
    }

    private void validateUser(final String phoneNumber, final String pin) {
        try {
            final User dbUser = userDAO.findByPhoneNumber(phoneNumber);

            if (!Objects.equals(dbUser.getPin(), pin)) {
                smsService.sendInvalidPin(phoneNumber);
                throw new IllegalArgumentException("Pin is incorrect");
            } else {
                user = dbUser;
            }
        } catch (NoResultException e) {
            smsService.sendInvalidPhoneNumber(phoneNumber);
            throw new IllegalArgumentException("Phone number is incorrect");
        }
    }

    private void signUp(final String name, final String phoneNumber, final String pin) {
        try {
            final User newUser = new User();
            newUser.setPin(pin);
            newUser.setName(name);
            newUser.setAccountBalance(10000d);
            newUser.setPhoneNumber(phoneNumber);
            newUser.setAccountNumber(RandomStringUtils.random(11, false, true));

            userDAO.save(newUser);

            smsService.sendWelcome(newUser);
        } catch (PersistenceException e) {
            smsService.sendPhoneNumberExists(phoneNumber);
        }
    }

    private void topUp(final String network, final String phoneNumber, final String amountString) {
        try {
            final double amount = Double.parseDouble(amountString);

            if (amount > user.getAccountBalance()) {
                smsService.sendInsufficientFunds(user);
            } else {
                airtimeService.topUp(network, phoneNumber, amount);

                final Transaction transaction = new Transaction();
                transaction.setUser(user);
                transaction.setAmount(amount);
                transaction.setMessage(phoneNumber);
                transaction.setType(Transaction.Type.AirtimeTopUp);
                transaction.setDirection(Transaction.Direction.Debit);

                user.setAccountBalance(user.getAccountBalance() - amount);

                userDAO.update(user);

                transactionDAO.save(transaction);

                smsService.sendDebit(user, transaction);
            }
        } catch (NumberFormatException ignored) {}
    }

    private void transfer(final String accountNumber, final String amountString) {
        try {
            final User recipient = userDAO.findByAccountNumber(accountNumber);

            final double amount = Double.parseDouble(amountString);

            if (amount > user.getAccountBalance()) {
                smsService.sendInsufficientFunds(user);
            } else {
                final Transaction debitTransaction = new Transaction();
                debitTransaction.setUser(user);
                debitTransaction.setAmount(amount);
                debitTransaction.setMessage(accountNumber);
                debitTransaction.setType(Transaction.Type.Transfer);
                debitTransaction.setDirection(Transaction.Direction.Debit);

                final Transaction creditTransaction = new Transaction();
                creditTransaction.setUser(recipient);
                creditTransaction.setAmount(amount);
                creditTransaction.setType(Transaction.Type.Transfer);
                creditTransaction.setDirection(Transaction.Direction.Credit);
                creditTransaction.setMessage(String.format("From %s", user.getName()));

                user.setAccountBalance(user.getAccountBalance() - amount);

                recipient.setAccountBalance(recipient.getAccountBalance() + amount);

                userDAO.update(user);

                userDAO.update(recipient);

                transactionDAO.save(debitTransaction);

                transactionDAO.save(creditTransaction);

                smsService.sendDebit(user, debitTransaction);

                smsService.sendCredit(recipient, creditTransaction);
            }
        } catch (NoResultException e) {
            smsService.sendInvalidAccountNumber(user, accountNumber);
        } catch (NumberFormatException ignored) {}
    }

    private void balance() {
        smsService.sendBalance(user);
    }
}
