package com.stephen.cuebue;

import lombok.Data;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class SMSService {
    private static final String SERVER_ID = "OKMTNTAUR";

    private static final String END_POINT = "https://simhostng.com/api/sms";
    private static final String API_KEY = "01c31d11e0722210ce2b7deee8e8126673486241482c8796fb253f706c09cd24";

    @Data
    public static class ResponseDto {
        private String ref;
        private String response;
        private String Date;
    }

    private ResponseDto send(final String recipientPhoneNumber, final String message) {
        final Client client = ClientBuilder.newClient();

        final Form form = new Form();

        form.param("apikey", API_KEY);
        form.param("server", SERVER_ID);
        form.param("message", message);
        form.param("number", recipientPhoneNumber);

        System.out.println(message + " - "+recipientPhoneNumber);

        return client.target(END_POINT)
                .request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED_TYPE), ResponseDto.class);
    }

    public void sendWelcome(final User user) {
        final ResponseDto responseDto = send(
            user.getPhoneNumber(),
            String.format(
                "Welcome to %s to Cuebue, \nyour account number is %s, \n and your account balance is NGN %f to use and try out our service.",
                user.getName(),
                user.getAccountNumber(),
                user.getAccountBalance()
            )
        );

        System.out.println(responseDto);
    }

    public void sendPhoneNumberExists(final String phoneNumber) {
        final ResponseDto responseDto = send(
            phoneNumber,
            String.format("This phone number %s is already registered on Cuebue.", phoneNumber)
        );

        System.out.println(responseDto);
    }

    public void sendInvalidPhoneNumber(final String phoneNumber) {
        final ResponseDto responseDto = send(
                phoneNumber,
                String.format("This phone number %s is invalid. Please make sure it is registered on Cuebue.", phoneNumber)
        );

        System.out.println(responseDto);
    }

    public void sendInvalidAccountNumber(final User user, final String accountNumber) {
        final ResponseDto responseDto = send(
                user.getPhoneNumber(),
                String.format("Cuebue transfer failed, as the account number %s is invalid.", accountNumber)
        );

        System.out.println(responseDto);
    }

    public void sendInvalidPin(final String phoneNumber) {
        final ResponseDto responseDto = send(phoneNumber, "You entered an incorrect Cuebue pin.");

        System.out.println(responseDto);
    }

    public void sendInsufficientFunds(final User user) {
        final ResponseDto responseDto = send(
            user.getPhoneNumber(),
    "Cuebue transfer failed due to insufficient funds in your account."
        );

        System.out.println(responseDto);
    }

    public void sendDebit(final User user, final Transaction transaction) {
        final ResponseDto responseDto = send(
                user.getPhoneNumber(),
                String.format(
                    "Cuebue Debit alert \n Amount: NGN %f \n Details: %s \n Date: %s",
                    transaction.getAmount(),
                    transaction.getMessage(),
                    transaction.getDate().toString()
                )
        );

        System.out.println(responseDto);
    }

    public void sendCredit(final User user, final Transaction transaction) {
        final ResponseDto responseDto = send(
                user.getPhoneNumber(),
                String.format(
                        "Cuebue Credit alert \n Amount: NGN %f \n Details: %s \n Date: %s",
                        transaction.getAmount(),
                        transaction.getMessage(),
                        transaction.getDate().toString()
                )
        );

        System.out.println(responseDto);
    }

    public void sendBalance(final User user) {
        final ResponseDto responseDto = send(
            user.getPhoneNumber(),
            String.format("Your Cuebue account balance is NGN %f", user.getAccountBalance())
        );

        System.out.println(responseDto);
    }
}
